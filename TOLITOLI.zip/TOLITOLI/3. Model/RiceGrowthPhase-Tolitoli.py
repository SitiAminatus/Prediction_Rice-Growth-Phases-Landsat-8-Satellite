# %%
import pandas as pd
import numpy as np

#read data 
df=pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\matchingksa_band.csv')
df.tail()



# %%
from matplotlib import pyplot as plt 
# Plot the dataframe
ax = df[['B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7']].plot(kind='box', title='boxplot')
#col='red','yellow','blue', 'green', 'pink','white', 'brown',
#df.boxplot (x='B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', y='ksa')

# Display the plot
plt.show()

# %%
import seaborn as sns
import matplotlib.pyplot as plt
sns.boxplot(x=df["ksa"], y=df["B1"],  width=0.2)

plt.show()

# %%
import seaborn as sns
import matplotlib.pyplot as plt
columns = ['B1','B2', 'B3', 'B4', 'B5', 'B6', 'B7']

for i in columns:
    sns.set(style = "ticks", palette = "pastel")

    box_plot = sns.boxplot(x="ksa", y=i,
                          palette=["m","g"],
                          width=0.3,
                          data=df)
    plt.show()

# %%
#membagi data into data input and data output (prediction)
X = df.drop('ksa',axis=1)
y = df['ksa']

# %% [markdown]
# Create data train and data test

# %%
#datatrain
Xdatatrain = X.iloc[:172]
Ydatatrain = y.iloc[:172]
print(Xdatatrain)
print(Ydatatrain)

#datatest
Xdatatest = X.iloc[172:]
Ydatatest = y.iloc[172:]
print(Xdatatest)
print(Ydatatest)

# %% [markdown]
# Define k-fold cross validation.
# Here I will use k=5

# %%
from sklearn.model_selection import StratifiedKFold

cv = StratifiedKFold(n_splits=5, random_state=1, shuffle=True)

# %%
Path = r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.'
fold_no = 1
for train_index, test_index in cv.split(Xdatatrain, Ydatatrain):
    print("FOLD ",fold_no)
    print("TRAIN:", train_index)
    print("TEST:", test_index)  

    Xtrain = Xdatatrain.iloc[train_index, :]
    Xtest = Xdatatrain.iloc[test_index, :]
    Ytrain = Ydatatrain[train_index]
    Ytest = Ydatatrain[test_index]

    Xtrain.to_csv(Path + 'Xtrain' + str(fold_no) + '.csv',index=False)
    Xtest.to_csv(Path + 'Xtest' + str(fold_no) + '.csv',index=False)
    Ytrain.to_csv(Path + 'Ytrain' + str(fold_no) + '.csv',index=False)
    Ytest.to_csv(Path + 'Ytest' + str(fold_no) + '.csv',index=False)

    fold_no += 1

# %%
#Data StratifiedKfold
#Fold1


xtrainfold1 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Xtrain1.csv')
xtestfold1 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Xtest1.csv')
ytrainfold1 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Ytrain1.csv')
ytestfold1 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Ytest1.csv')

#Fold2
xtrainfold2 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Xtrain2.csv')
xtestfold2 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Xtest2.csv')
ytrainfold2 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Ytrain2.csv')
ytestfold2 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Ytest2.csv')

#Fold3
xtrainfold3 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Xtrain3.csv')
xtestfold3 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Xtest3.csv')
ytrainfold3 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Ytrain3.csv')
ytestfold3 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Ytest3.csv')

#Fold4
xtrainfold4 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Xtrain4.csv')
xtestfold4 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Xtest4.csv')
ytrainfold4 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Ytrain4.csv')
ytestfold4 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Ytest4.csv')

#Fold5
xtrainfold5 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Xtrain5.csv')
xtestfold5 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Xtest5.csv')
ytrainfold5 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Ytrain5.csv')
ytestfold5 = pd.read_csv(r'C:\Users\AMINA\Documents\belajar python\kevin\Data10Fold\.Ytest5.csv')




# %%
#RobustScaler
from sklearn.preprocessing import RobustScaler
sc = RobustScaler()
xtrain1 = sc.fit_transform(xtrainfold1)
xtest1 = sc.transform (xtestfold1)

xtrain2 = sc.fit_transform(xtrainfold2)
xtest2 = sc.transform (xtestfold2)

xtrain3 = sc.fit_transform(xtrainfold3)
xtest3 = sc.transform (xtestfold3)

xtrain4 = sc.fit_transform(xtrainfold4)
xtest4 = sc.transform (xtestfold4)

xtrain5 = sc.fit_transform(xtrainfold5)
xtest5 = sc.transform (xtestfold5)



# %%
ytrain1 = ytrainfold1["ksa"].astype("category")
ytrain2 = ytrainfold2["ksa"].astype("category")
ytrain3 = ytrainfold3["ksa"].astype("category")
ytrain4 = ytrainfold4["ksa"].astype("category")
ytrain5 = ytrainfold5["ksa"].astype("category")

ytest1 = ytestfold1["ksa"].astype("category")
ytest2 = ytestfold2["ksa"].astype("category")
ytest3 = ytestfold3["ksa"].astype("category")
ytest4 = ytestfold4["ksa"].astype("category")
ytest5 = ytestfold5["ksa"].astype("category")

# %%
import tensorflow
from keras.models import Sequential
from keras.layers import Dense, Input
from keras.models import Model
from tensorflow.keras.optimizers import Adam
from keras.layers import Dropout
#Setting Optimizer
opt = Adam(learning_rate=0.001,beta_1=0.9, beta_2=0.999, epsilon=1e-08)
#Membangun Model    
model01 = Sequential()
model01.add(Dense(20, activation = "selu", input_dim=14, use_bias=True,
kernel_initializer='random_normal',bias_initializer='zeros'))
model01.add(Dense(30, activation = "selu", use_bias=True,
kernel_initializer='random_normal',bias_initializer='zeros'))
model01.add(Dropout(0.2))
model01.add(Dense(15, activation = "selu", use_bias=True,
kernel_initializer='random_normal',bias_initializer='zeros'))
model01.add(Dense(5, activation = "softmax",use_bias=True,
kernel_initializer='random_normal',bias_initializer='zeros'))
model01.compile(loss='categorical_crossentropy', optimizer=opt, metrics=['accuracy'])
model01.summary()


